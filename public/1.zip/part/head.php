<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">


    <!-- 구글 폰트 불러오기 -->
    <!-- rotobo(400/900), notosanskr(400/900) -->
    <link
        href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR:wght@400;900&family=Roboto:wght@400;900&display=swap"
        rel="stylesheet">

    <!-- 폰트어썸 불러오기 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css">

    <!-- 제이쿼리 불러오기 -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


    <link rel="stylesheet" href="/resource/common.css">
    <script src="/resource/common.js"></script>

    <title>kitchendogue</title>
</head>


<body>

    <div class="top-bar">
        <div class="con flex height-100p">
            <nav class="menu-box menu-box-1">
                <ul class="flex height-100p">
                    <li class="flex"><a href="#" class="flex flex-ai-c  flex-jc-c">FOLLOW US</a></li>
                    <li class="flex"><a href="#" class="flex flex-ai-c  flex-jc-c"><i class="fab fa-facebook-f"></i></a>
                    </li>
                    <li class="flex"><a href="#" class="flex flex-ai-c  flex-jc-c"><i class="fab fa-instagram"></i></a></li>
                </ul>
            </nav>

            <div class="flex-grow-1"></div>

            <nav class="menu-box menu-box-2">
                <ul class="flex height-100p">
                    <li class="flex"><a href="#" class="flex flex-ai-c  flex-jc-c">LANGUAGET</a></li>
                    <li class="flex"><a href="#" class="flex flex-ai-c  flex-jc-c">LOCAL SITE</a></li>
                </ul>
            </nav>

            <nav class="menu-box menu-box-3">
                <ul class="flex height-100p">
                    <li class="flex"><a href="#" class="flex flex-ai-c  flex-jc-c"><i class="fas fa-user"></i></a></li>
                    <li class="flex"><a href="#" class="flex flex-ai-c  flex-jc-c"><i class="fas fa-search"></i></a></li>
                    <li class="flex"><a href="#" class="flex flex-ai-c  flex-jc-c"><i class="fas fa-ellipsis-h"></i></a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>


    <div class="top-2-bar">
        <div class="con con-2 height-100p flex flex-jc-sb">
            <!-- flex-jc-sb 양쪽 끝에는 붙고  사이 간격 일정하게 벌어지게 하는 것-->
            <a href="/" class="logo flex-ai-c">
                <img src="https://img1.daumcdn.net/thumb/R1280x0/?scode=mtistory2&fname=https%3A%2F%2Fk.kakaocdn.net%2Fdn%2FdeatEi%2FbtqE5QryJVv%2FNtGT5u1eAPk5qV2U9BvfF0%2Fimg.png"
                    alt="">
            </a>
            <nav class="menu-box menu-box-1">
                <ul class="flex height-100p">
                    <li class="flex"><a href="#" class="flex flex-ai-c flex-as-c">OUR STORY</a></li>
                    <li class="flex"><a href="#" class="flex  flex-ai-c flex-as-c">PRODUCT</a></li>
                    <li class="flex "><a href="#" class="flex flex-ai-c flex-as-c">NEW&TALK</a></li>
                </ul>
            </nav>

            <nav class="menu-box menu-box-2">
                <ul class="flex height-100p">
                    <li class="flex"><a href="#" class="flex-ai-c flex-as-c">CONTECT US</a></li>
                </ul>
            </nav>
        </div>
    </div>

    <div class="bn-box-1" style="background-image:url(/resource/img/bn1.jpg);">
    </div>
    <div class="bn-box-2" style="background-image:url(/resource/img/bn2.jpg);">
    </div>