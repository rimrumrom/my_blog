<?php
include "../part/head.php";
?>
<h1>내용</h1>
<img src="/resource/img/1.png" alt="">
<?php
include "../part/foot.php";
?>